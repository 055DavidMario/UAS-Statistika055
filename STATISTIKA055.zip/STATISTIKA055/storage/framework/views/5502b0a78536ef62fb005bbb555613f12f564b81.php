<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    </head>
<body>
	<style type="text/css">
		table tr td,
		table tr th{
			font-size: 9pt;
		}
	</style>
	<center>
		<h2 class="text-center text-primary">Data</h3>
	</center>

	<table class="table table-bordered table-striped">
		<thead>

            <tr>
                <th scope="col">No</th>
                <th scope="col">NIM</th>
                <th scope="col">Nama</th>
                <th scope="col">Nilai</th>
                <th scope="col">Kelas</th>
            </tr>
		</thead>

		<tbody>
        
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($loop->iteration); ?></th>
            <td><?php echo e($s->NIM); ?></td>
            <td><?php echo e($s->Name); ?></td>
            <td><?php echo e($s->Score); ?></td>
            <td><?php echo e($s->Nilai); ?></td>
            <td><?php echo e($s->Kelas); ?></td>
          </tr>
        // <?php
        //     $i++;
        // ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
</body>
</html>
<?php /**PATH D:\UNDIKSHA\SEMESTER III\Statistik\PUNYA DAVID v8\STATISTIKA055\resources\views/statistika/printData.blade.php ENDPATH**/ ?>